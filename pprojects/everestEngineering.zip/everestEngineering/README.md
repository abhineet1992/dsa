# everestEngineering

## How to Run

### Challenge One

To run the solution for Challenge One (delivery cost estimation):

```sh
python [cli.py](http://_vscodecontentref_/0)
```

To run the solution for Challenge Two:

python [main.py](http://_vscodecontentref_/1)
